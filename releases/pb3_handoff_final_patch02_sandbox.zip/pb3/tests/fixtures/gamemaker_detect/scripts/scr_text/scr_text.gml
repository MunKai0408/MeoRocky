// GameMaker script
