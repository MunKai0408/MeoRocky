# Sinh bởi: python3 menu.py plugin new format demo_tg
# Đọc docs/SDK_CONTRACT.md. Thêm plugin = chạy mã trên máy bạn (đặc tả 4.7); đây không phải sandbox.
# Kiểm tra: python3 menu.py plugin test demo_tg
from sdk.api import Plugin
from sdk.types import Candidate, Evidence, LocEntry, LocTable, SourceRef

MANIFEST = {
    "id": "demo_tg",
    "name": "Demo Tg",
    "version": "0.1.0",
    "api_version": 3,
    "kind": "format",
    "capabilities": ["read"],
    "maturity": "M1",  # M2 khi parse đã test trên fixture; M3/M4 cần ghi ngược + bằng chứng (tests/corpus/demo_tg.json)
    "priority": 40,
    "true_cost": "cheap",
    "engines": ["generic"],
    "match": {"extensions": [".txt"]},
    "limits": {"max_entry_bytes": 16 * 1024 * 1024, "hook_timeout_s": 10},
    "entry": "plugin:DemoTgPlugin",
    "selftest": True,
    "docs": "Mẫu: dòng KEY=value, bỏ dòng bắt đầu bằng #. CHƯA test trên game thật; sửa mô tả này khi biết giới hạn.",
}


def _pairs(text):
    for i, ln in enumerate(text.splitlines()):
        s = ln.strip()
        if s and not s.startswith("#") and "=" in s:
            k, v = s.split("=", 1)
            yield i + 1, k.strip(), v.strip()


def _table(data, path, locale):
    entries, conflicts, seen = [], [], set()
    for line, k, v in _pairs(data.decode("utf-8", errors="replace")):
        if k in seen:
            conflicts.append({"key": k, "line": line})
            continue
        seen.add(k)
        src = SourceRef(container_stack=[path], rel_path=path, entry_offset=None,
                        entry_size=len(data), encoding="utf-8", extra={})
        entries.append(LocEntry(key=k, value=v, locale=None, key_origin="native", status="ok", source=src))
    return LocTable(entries=entries, locale=locale, adapter_id=MANIFEST["id"], schema_hint={},
                    stats={"entries": len(entries)}, conflicts=conflicts, warnings=[])


class DemoTgPlugin(Plugin):
    MANIFEST = MANIFEST

    def detect(self, ctx):
        return [Evidence(kind="extension", value=".txt", weight=0.2, reason="tên file gợi ý bảng text")]

    def list_candidates(self, ctx):
        out = []
        for p in ctx.vfs.iter_entries():
            if not p.lower().endswith(".txt"):
                continue
            head = ctx.vfs.read(p, max_bytes=4096)
            if b"=" in head and b"\x00" not in head:
                out.append(Candidate(path=p, adapter_id=MANIFEST["id"], score=0.5, reasons=["có dấu ="]))
        return out

    def probe(self, ctx, cand):
        text = ctx.vfs.read(cand.path, max_bytes=64 * 1024).decode("utf-8", errors="replace")
        return {"schema": "key=value", "pairs": sum(1 for _ in _pairs(text))}

    def parse(self, ctx, cand):
        return _table(ctx.vfs.read(cand.path, max_bytes=ctx.limits.max_entry_bytes), cand.path, ctx.locale.code)

    def selftest(self, ctx):
        t = _table(b"a=1\n# c\nb=2\na=3\n", "selftest.txt", None)
        return {"ok": [e.key for e in t.entries] == ["a", "b"] and len(t.conflicts) == 1}

    # Không có build(): plugin chỉ đọc. Muốn ghi ngược: thêm "write" vào capabilities, "write_modes", build(), verify().
